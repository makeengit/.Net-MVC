﻿using Microsoft.EntityFrameworkCore;
using mvc_Bahwan.Models;

namespace mvc_Bahwan.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        { 

        }

    public DbSet<Product> products { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}
