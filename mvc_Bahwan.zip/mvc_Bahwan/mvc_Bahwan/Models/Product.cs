﻿using System.ComponentModel.DataAnnotations.Schema;

namespace mvc_Bahwan.Models
{
    public class Product
    {
        public int Productid { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set;}
        public decimal Discount { get; set;}
        public decimal Total { get; set; }

        public int CategoryId { get; set; }
        [ForeignKey("CategoryId")]
        public Category  Category { get; set; }

    }
}
