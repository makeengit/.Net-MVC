﻿namespace mvc_Bahwan.Models
{
	public class Category
	{
        public int id { get; set; }
        public string Name { get; set; }
    }
}
